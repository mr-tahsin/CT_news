<?php
include("includes/header.php");
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Comment Section</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Manage Comments</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div><!-- /.content-header -->



    <?php
    $variable = isset($_GET['ystruvx']) ? $_GET['ystruvx'] : "manage";

    if ($variable == "manage") { ?>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card card-secondary">
                            <div class="card-header">
                                <h3 class="card-title">All Comments</h3>
                            </div>
                            <div class="card-body">
                                <table class="table table-striped table-bordered     table-responsive">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>#</th>
                                            <th>Post title</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Comments</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                            <th>Approval</th>
                                            <th>Delete</th>
                                        </tr>
                                    </thead>


                                    <tbody>
                                        <?php
                                        $sl = 1;
                                        $sql = "SELECT * FROM comments ORDER by cmt_id desc";
                                        $query = mysqli_query($db, $sql);
                                        while ($row = mysqli_fetch_assoc($query)) {
                                            $cmt_id = $row['cmt_id'];
                                            $cmt_post_id = $row['cmt_post_id'];
                                            $cmt_name = $row['cmt_name'];
                                            $cmt_email = $row['cmt_email'];
                                            $cmt_message = $row['cmt_message'];
                                            $cmt_status = $row['cmt_status'];
                                            $cmt_date = $row['cmt_date'];
                                        ?>

                                            <tr>

                                                <td><?php echo $sl; ?></td>
                                                <td>
                                                    <?php
                                                    $sql = "SELECT * FROM post";
                                                    $bring_post_name = mysqli_query($db, $sql);
                                                    while ($row = mysqli_fetch_assoc($bring_post_name)) {
                                                        $post_id = $row['post_id'];
                                                        $title = $row['title'];

                                                        if ($post_id == $cmt_post_id) {
                                                            echo $title;
                                                        }
                                                    }

                                                    ?>
                                                </td>
                                                <td><?php echo $cmt_name; ?></td>
                                                <td><?php echo $cmt_email; ?></td>
                                                <td><?php echo substr($cmt_message, 0, 15) . "..."; ?> <br><a href="comment.php?ystruvx=full_comment&fullcomment=<?php echo $cmt_id; ?>">Full comment</a></td>
                                                <td>
                                                    <?php
                                                    if ($cmt_status == 420) { ?>
                                                        <div class="badge badge-danger badge-btn">Draft</div>
                                                    <?php } else if ($cmt_status == 1) { ?>
                                                        <div class="badge badge-success badge-btn">Published</div>
                                                    <?php }
                                                    ?>
                                                </td>
                                                <td><?php echo $cmt_date; ?></td>
                                                <td>
                                                    <div class="action-menu">
                                                        <ul>
                                                            <li><a href="comment.php?ystruvx=edit&id=<?php echo $cmt_id; ?>" class="text-secondary"><i class="fas fa-edit"></i></a></li>
                                                        </ul>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="action-menu">
                                                        <ul>
                                                            <li>
                                                                <a href="#" class="text-danger" data-toggle="modal" data-target="#faruque<?php echo $cmt_id; ?>"><i class="fas fa-trash"></i></a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </td>

                                                <!--Delete Modal Start-->
                                                <div class="modal fade" id="faruque<?php echo $cmt_id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Are you sure?</h5>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <a href="comment.php?ystruvx=delete&user=<?php echo $cmt_id; ?>">
                                                                    <input type="submit" class="btn btn-danger btn-sm btn-flat" value="Yes">
                                                                </a>
                                                                <a href="#">
                                                                    <input type="submit" class="btn btn-success btn-sm btn-flat" data-dismiss="modal" value="No">
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--Delete Modal End-->
                                            </tr>
                                        <?php
                                            $sl++;
                                        }
                                        ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php } else if ($variable == "full_comment") {
        if (isset($_GET['fullcomment'])) {
            $store_full_comment = $_GET['fullcomment'];
            $sql = "SELECT * FROM comments WHERE cmt_id = '$store_full_comment' ";
            $query = mysqli_query($db, $sql);
            while ($row = mysqli_fetch_assoc($query)) {
                $cmt_name = $row['cmt_name'];
                $cmt_message = $row['cmt_message'];
                $cmt_post_id = $row['cmt_post_id'];
            } ?>

            <section class="content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card card-secondary">
                                <div class="card-header">
                                    <?php
                                    $sql = "SELECT * FROM post WHERE post_id = '$cmt_post_id' ";
                                    $new_query = mysqli_query($db, $sql);
                                    while ($new_row = mysqli_fetch_assoc($new_query)) {
                                        $title = $new_row['title'];
                                    } 
                                    ?>

                                    <h3 class="card-title">Full comment of <b><?php echo $cmt_name; ?></b> on <b><?php echo $title; ?></b> post. </h3>
                                </div>
                                <div class="card-body">
                                    <?php echo $cmt_message; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <?php  }
    } else if ($variable == "edit") {
        if (isset($_GET['id'])) {
            $store_edit = $_GET['id'];

            $sql = "SELECT * FROM comments WHERE cmt_id = '$store_edit'";
            $query = mysqli_query($db, $sql);
            while ($row = mysqli_fetch_assoc($query)) {
                $cmt_status = $row['cmt_status'];
            ?>
                <section class="content">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card card-secondary">
                                    <div class="card-header">
                                        <h3 class="card-title">
                                            Comment's approval
                                        </h3>
                                    </div>
                                    <div class="card-body">
                                        <form action="comment.php?ystruvx=update" method="POST">
                                            <div class="form-group">
                                                <label for="approval">Select one</label>
                                                <select name="cmt_status" class="form-control" id="approval">
                                                    <option value="420" <?php
                                                                        if ($cmt_status == 420) {
                                                                            echo "selected";
                                                                        }
                                                                        ?>> Draft
                                                    </option>

                                                    <option value="1" <?php
                                                                        if ($cmt_status == 1) {
                                                                            echo "selected";
                                                                        }
                                                                        ?>> Published

                                                    </option>

                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <input type="hidden" value="<?php echo $store_edit; ?>" name="yzdkjkdfk">
                                                <input type="submit" class="btn btn-secondary btn-flat btn-sm">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
    <?php }
        }
    } else if ($variable == "update") {
        if (isset($_POST['yzdkjkdfk'])) {
            $store_update = $_POST['yzdkjkdfk'];

            $cmt_status = $_POST['cmt_status'];

            $sql = "UPDATE comments SET cmt_status='$cmt_status' WHERE cmt_id='$store_update'";
            $query = mysqli_query($db, $sql);
            if ($query) {
                header("location:comment.php");
            }
        }
    } else if ($variable == "delete") {
        if (isset($_GET['user'])) {
            $store_delete = $_GET['user'];
            $sql = "DELETE FROM comments WHERE cmt_id= '$store_delete'";
            $query = mysqli_query($db, $sql);
            if ($query) {
                header("location:comment.php?ystruvx=manage");
            }
        }
    }
    ?>



</div>

<?php
include("includes/footer.php");
?>