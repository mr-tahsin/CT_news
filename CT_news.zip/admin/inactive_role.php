<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="A complete workable dynamic news website name CT News developed by Tahsin Faruque">
    <meta property="og:image" content="dist/img/ctlogo.png">
    <meta name="keywords" content="html, css, javascript, jquery, php, mysql, coder tahsin, mahi tahsin,web developer; website builder; website designer; ecommerce website; codertahsin.com; Tahsin Faruque; best web developer in BD; bangladesh; ecommerce business; best motivator; Dhaka; Shikhbe Shobai; ForidRony; landing page; best programmer in bd; best programmer and web developer in fiverr; best programmer and web developer in upwork; best programmer and web developer in freelancer; best programmer and web developer in payperhour; weebly best website builder; shopify best website builder; squarespace best website builder; wordpress; best wordpress developer in Bangladesh; Pakistan; India; astra developer; avada developer; java; best php web developer, newsportal site,web design, SEO">
    <meta name="author" content="Tahsin Faruque">

    <!--icon-->
    <link rel="icon" href="dist/img/cticon.png">
    <title>Inactive User Warning</title>
</head>

<body>

    <h2><b>You have no login access right now. You can login when admin will approve you. </b></h2>
</body>

</html>