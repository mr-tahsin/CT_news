<!--NO TURN ANGLE CONDITION USED-->
<?php
include("includes/header.php");
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Category</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Manage Category</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div><!-- /.content-header -->


    <!-- Main content Start-->
    <section class="content">
        <div class="container-fluid">
            <!-- Info boxes -->
            <div class="row">


                <!--left Column Start-->
                <!--Edit Start-->
                <?php
                if (isset($_GET['edit'])) {
                    $the_cat_id = $_GET['edit'];
                    $sql = "SELECT * FROM categories WHERE cat_id = '$the_cat_id' ";
                    $updateConn1 = mysqli_query($db, $sql);
                    while ($row = mysqli_fetch_assoc($updateConn1)) {

                        $cat_id = $row['cat_id'];
                        $cat_name = $row['cat_name'];
                        $cat_desc = $row['cat_desc'];
                        $cat_status = $row['cat_status'];
                ?>

                        <div class="col-md-6">
                            <div class="card card-info">
                                <div class="card-header ">
                                    <h3 class="card-title">Edit Category</h3>
                                </div>
                                <div class="card-body">
                                    <form action="" method="POST">
                                        <div class="form-group">
                                            <label for="name">Name</label>
                                            <input type="text" class="form-control" id="name" autocomplete="off" value="<?php echo $cat_name; ?>" name="name">
                                        </div>

                                        <div class="form-group">
                                            <label for="desc">Description</label>
                                            <textarea id="desc" class="form-control" rows="3" name="desc"><?php echo $cat_desc; ?></textarea>
                                        </div>

                                        <div class="form-group">
                                            <label for="status">Select status</label>
                                            <select id="status" class="form-control" name="status">
                                                <option value="420" <?php if ($cat_status == 420) {
                                                                        echo "selected";
                                                                    } ?>>Inactive</option>
                                                <option value="1" <?php if ($cat_status == 1) {
                                                                        echo "selected";
                                                                    } ?>>Active</option>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <input type="submit" class="btn btn-info btn-sm" value="Save changes" name="UpdateCat">
                                        </div>
                                    </form>
                                    <?php
                                    if (isset($_POST['UpdateCat'])) {
                                        $name = $_POST['name'];
                                        $desc = $_POST['desc'];
                                        $status = $_POST['status'];

                                        $sql = "UPDATE categories SET cat_name= '$name', cat_desc= '$desc', cat_status ='$status' WHERE cat_id = '$cat_id' ";

                                        $updateConn2 = mysqli_query($db, $sql);
                                        if ($updateConn2) {
                                            header("location:category.php");
                                        } else {
                                            die("Something went wrong" . mysqli_error($updateConn2));
                                        }
                                    }
                                    ?>

                                </div>
                            </div>
                        </div>

                <?php  }
                }
                ?>
                <!--Edit End-->


                <!--Insert Start-->
                <div class="col-md-6">
                    <div class="card card-info">
                        <div class="card-header ">
                            <h3 class="card-title">Add New Category</h3>
                        </div>
                        <div class="card-body">
                            <form action="" method="POST">
                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input type="text" class="form-control" id="name" autocomplete="off" name="name">
                                </div>

                                <div class="form-group">
                                    <label for="desc">Description</label>
                                    <textarea id="desc" class="form-control" rows="3" name="desc"></textarea>
                                </div>

                                <div class="form-group">
                                    <label for="status">Select status</label>
                                    <select id="status" class="form-control" name="status">
                                        <option value="420">Inactive</option>
                                        <option value="1">Active</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <input type="submit" class=" btn btn-info btn-sm" value="Add status" name="submit">
                                </div>
                            </form>
                        </div>
                    </div>
                    <!--Card End for left column-->
                </div>
                <!--left Column End-->


                <?php
                if (isset($_POST['submit'])) {
                    $name = $_POST['name'];
                    $desc = $_POST['desc'];
                    $status = $_POST['status'];

                    $sql = "INSERT INTO categories (cat_name, cat_desc, cat_status) VALUES ('$name', '$desc', '$status')";
                    $Insertcon = mysqli_query($db, $sql);

                    if ($Insertcon) {
                        header("Location: category.php");
                    } else {
                        die("Something happened wrong!" . mysqli_error($Insertcon));
                    }
                }
                ?>
                <!--Insert End-->
                <!--Left column end-->


                <!--right Column Start-->
                <div class="col-md-6">
                    <div class="card card-info">
                        <div class="card-header ">
                            <h3 class="card-title">All Category</h3>
                        </div>
                        <div class="card-body">
                            <!--Table Start-->
                            <table class="table table-responsive table-bordered table-striped">
                                <thead class="thead-dark">
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Category Name</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sl = 1;
                                    $sql = "SELECT * FROM categories";
                                    $all_cat = mysqli_query($db, $sql);
                                    while ($row = mysqli_fetch_assoc($all_cat)) {
                                        $cat_id = $row['cat_id'];
                                        $cat_name = $row['cat_name'];
                                        $cat_desc = $row['cat_desc'];
                                        $cat_status = $row['cat_status'];

                                    ?>
                                        <tr>
                                            <th scope="row"><?php echo $sl; ?></th>
                                            <td><?php echo $cat_name; ?></td>
                                            <td>
                                                <?php if ($cat_status == 1) {
                                                    echo '<div class="badge badge-success">Active</div>';
                                                } else {
                                                    echo '<div class="badge badge-danger">Inactive</div>';
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <div class="action-menu">
                                                    <ul>
                                                        <li>
                                                            <a href="category.php?edit=<?php echo $cat_id; ?>" class="text-info"><i class="fas fa-edit" data-toggle="tooltip" data-placement="top" title="Edit Category"></i></a>
                                                        </li>
                                                        <li>
                                                            <a href="" data-toggle="modal" class="text-danger" data-target="#hi<?php echo $cat_id; ?>"><i class="fas fa-trash-alt" data-toggle="tooltip" data-placement="top" title="Delete Category"></i>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </td>

                                            <!-- Confirm Delete Modal Start -->
                                            <div class="modal fade" id="hi<?php echo $cat_id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Are you sure? </h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body text-center">
                                                            <div class="modal-button catlist">
                                                                <ul>
                                                                    <li>
                                                                        <a href="category.php?delete=<?php echo $cat_id; ?>" class="btn btn-md btn-danger">Yes</a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="#"><button data-dismiss="modal" class="btn btn-md btn-success">No</button></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Confirm Delete Modal End -->


                                        </tr>

                                    <?php $sl++;
                                    } ?>






                                </tbody>
                            </table>
                            <!--Table End-->
                        </div>
                        <!--Card body end-->



                    </div>
                </div>
                <!--right Column end-->
            </div>
        </div>

    </section>
</div>


<!--Delete Query-->
<?php if (isset($_GET['delete'])) {
    $deleteid = $_GET['delete'];
    $catsql = "DELETE FROM categories WHERE cat_id = '$deleteid' ";
    $catdelete = mysqli_query($db, $catsql);

    if ($catdelete) {
        header("Location: category.php");
    } else {
        die("Something happened wrong!" . mysqli_error($db));
    }
} ?>


<?php
include("includes/footer.php");
?>