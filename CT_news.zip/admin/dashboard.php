<?php include("includes/header.php");
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">CT News Dashboard</h1>
        </div><!-- /.col -->
        <!-- <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Dashboard v2 </li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <!-- Info boxes -->
      <!-- Small boxes (Stat box) -->
      <div class="row">

        <?php
        if ($_SESSION['role'] != 2) { ?>

          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <?php
                $sql = "SELECT * FROM users WHERE role= 420";
                $query = mysqli_query($db, $sql);
                $stored_users = mysqli_num_rows($query);
                ?>
                <h3><?php echo $stored_users ?></h3>
                <p>Unapproved users</p>
              </div>
              <div class="icon">
                <i class="fas fa-users"></i>
              </div>
              <a href="users.php?do=manage" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->

        <?php }
        ?>
        <div class="col-lg-3 col-6">
          <!-- small box -->
          <div class="small-box bg-danger">
            <div class="inner">
              <?php
              $sql = "SELECT * FROM categories";
              $query = mysqli_query($db, $sql);
              $total_cat = mysqli_num_rows($query);
              ?>

              <h3><?php echo $total_cat; ?></h3>
              <p>Total categories</p>
            </div>
            <div class="icon">
              <i class="far fa-calendar-check"></i>
            </div>
            <a href="category.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->

        <div class="col-lg-3 col-6">
          <!-- small box -->
          <div class="small-box bg-info">
            <div class="inner">
              <?php
              $sql = "SELECT * FROM post";
              $query = mysqli_query($db, $sql);
              $count_post = mysqli_num_rows($query);

              ?>
              <h3><?php echo $count_post; ?></h3>
              <p>Total News</p>
            </div>
            <div class="icon">
              <i class="far fa-newspaper"></i>
            </div>
            <a href="blog.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-6">
          <!-- small box -->
          <div class="small-box bg-warning">
            <div class="inner">
              <?php
              $sql = "SELECT * FROM comments WHERE cmt_status = 420";
              $query = mysqli_query($db, $sql);
              $count_comments = mysqli_num_rows($query);
              ?>

              <h3><?php echo $count_comments; ?></h3>
              <p>Unapproved comments</p>
            </div>
            <div class="icon">
              <i class="fas fa-comment-slash"></i>
            </div>
            <a href="comment.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
          </div>
        </div>

      </div>
      <!-- /.row -->


      <div class="row pt-3">
        <div class="col-md-12">
          <h5>This is the admin panel section of this news site. <a href="../index.php" target="_blank">Click</a> to visit reader's section. Feel free to <a href="https://codertahsin.com#contact-section" target="_blank">contact</a> to buy, modify or add more features to this site.</h5>
        </div>
      </div>
    </div>
    <!--/. container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
  <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->

<?php include("includes/footer.php") ?>