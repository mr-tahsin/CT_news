<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
  <!-- Left navbar links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
    </li>
    <li class="nav-item d-none d-sm-inline-block">
      <a href="https://codertahsin.com#contact-section" target="_blank" class="nav-link">Contact Us</a>
    </li>
  </ul>



  <?php
  if ($_SESSION['role'] != 100) { ?>
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="settings_for_all.php?tahsin=edit" role="button">
          <i class="fas fa-cog"></i>
        </a>
      </li>
    </ul>
  <?php }
  ?>

</nav>
<!-- /.navbar -->