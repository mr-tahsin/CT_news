<?php
$db = mysqli_connect("codertahsin.com", "codertahsin", "tahsinfaruque96", "ct_news_php");

if ($db) {
    /* echo "Database connected successfully"; */
} else {
    die("Operation failed" . mysqli_error($db));
}
