<?php
ob_start();
session_start();
require("includes/db.php");

if ($_SESSION['role'] == 420) {
  header("location:inactive_role.php");
} else if (!$_SESSION['email']) {
  header("location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CT News Dashboard</title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="A complete workable dynamic news website name CT News developed by Tahsin Faruque">
  <meta property="og:image" content="dist/img/ctlogo.png">
  <meta name="keywords" content="html, css, javascript, jquery, php, mysql, coder tahsin, mahi tahsin,web developer; website builder; website designer; ecommerce website; codertahsin.com; Tahsin Faruque; best web developer in BD; bangladesh; ecommerce business; best motivator; Dhaka; Shikhbe Shobai; ForidRony; landing page; best programmer in bd; best programmer and web developer in fiverr; best programmer and web developer in upwork; best programmer and web developer in freelancer; best programmer and web developer in payperhour; weebly best website builder; shopify best website builder; squarespace best website builder; wordpress; best wordpress developer in Bangladesh; Pakistan; India; astra developer; avada developer; java; best php web developer, newsportal site,web design, SEO">
  <meta name="author" content="Tahsin Faruque">

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!--News Portal with PHP custom css-->
  <link rel="stylesheet" href="dist/css/style.css">
  <!--icon-->
  <link rel="icon" href="dist/img/cticon.png">
</head>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
  <div class="wrapper">

    <?php include("includes/topmenu.php") ?>
    <?php include("includes/leftmenu.php") ?>