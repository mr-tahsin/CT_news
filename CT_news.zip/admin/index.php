<?php
ob_start();
require("includes/db.php");
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="A complete workable dynamic news website name CT News developed by Tahsin Faruque">
    <meta property="og:image" content="dist/img/ctlogo.png">
    <meta name="keywords" content="html, css, javascript, jquery, php, mysql, coder tahsin, mahi tahsin,web developer; website builder; website designer; ecommerce website; codertahsin.com; Tahsin Faruque; best web developer in BD; bangladesh; ecommerce business; best motivator; Dhaka; Shikhbe Shobai; ForidRony; landing page; best programmer in bd; best programmer and web developer in fiverr; best programmer and web developer in upwork; best programmer and web developer in freelancer; best programmer and web developer in payperhour; weebly best website builder; shopify best website builder; squarespace best website builder; wordpress; best wordpress developer in Bangladesh; Pakistan; India; astra developer; avada developer; java; best php web developer, newsportal site,web design, SEO">
    <meta name="author" content="Tahsin Faruque">
    <title>CTN Login</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.min.css">

    <!--icon-->
    <link rel="icon" href="dist/img/cticon.png">
</head>


<?php
//Empty email, Empty password, Invalid email, Invalid Password, session login & role = 0 can't enter dashboard//

$email_empty = "";
$password_empty = "";
$invalid_password = "";
$invalid_email = "";

if (isset($_POST['login'])) {
    if (!empty($_POST['email'])) {
        if (!empty($_POST['password'])) {
            $email = mysqli_real_escape_string($db, $_POST['email']);
            $password = mysqli_real_escape_string($db, $_POST['password']);
            $shapass = sha1($password);
            $sql = "SELECT * FROM users WHERE email = '$email' ";
            $query = mysqli_query($db, $sql);
            $email_count = mysqli_num_rows($query);
            if ($email_count) {
                $sql = "SELECT * FROM users WHERE password = '$shapass'";
                $query = mysqli_query($db, $sql);
                $pass_count = mysqli_num_rows($query);
                if ($pass_count) {
                    $sql = "SELECT * FROM users WHERE email = '$email'";
                    $query = mysqli_query($db, $sql);
                    while ($row = mysqli_fetch_assoc($query)) {
                        $_SESSION['id'] = $row['id'];
                        $_SESSION['fullname'] = $row['fullname'];
                        $_SESSION['batch_id'] = $row['batch_id'];
                        $_SESSION['username'] = $row['username'];
                        $_SESSION['image'] = $row['image'];
                        $_SESSION['email'] = $row['email'];
                        $_SESSION['phone'] = $row['phone'];
                        $_SESSION['gender'] = $row['gender'];
                        $_SESSION['role'] = $row['role'];
                        $_SESSION['password'] = $row['password'];
                    }
                    if ($_SESSION['role'] == 420) {
                        header("location:inactive_role.php");
                    } else {
                        if ($email == $_SESSION['email'] && $shapass == $_SESSION['password']) {
                            header("Location:dashboard.php");
                        }
                    }
                } else {
                    $invalid_password = '<div class="btn btn-sm btn-outline-danger mt-3 d-block btn-flat">Password incorrect</div>';
                }
            } else {
                $invalid_email = '<div class="btn btn-sm btn-outline-danger mt-3 d-block text-left btn-flat">Your email doesn\'t match any account. <a href="signup.php">Create new account</a> </div>';
            }
        } else {
            $password_empty = '<div class="btn btn-sm btn-outline-danger mt-3 d-block btn-flat">Password field was empty</div>';
        }
    } else {
        $email_empty = '<div class="btn btn-sm btn-outline-danger mt-3 d-block btn-flat">Email field was empty</div>';
    }
}
?>


<?php
?>

<body class="hold-transition login-page pt-5 mt-2">
    <div class="login-box">
        <div class="login-logo">
            <a href="index.php"><b>CT News</b></a>
        </div>
        <!-- /.login-logo -->
        <div class="card">
            <div class="card-body login-card-body">
                <h4 class="mb-4">Log In</h4>

                <form action="" method="POST">
                    <div class="input-group mb-3">
                        <input type="email" class="form-control" placeholder="Email" autocomplete="" name="email">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-envelope"></span>
                            </div>
                        </div>
                    </div>
                    <div class="input-group mb-3">
                        <input type="password" class="form-control" placeholder="Password" autocomplete="off" name="password">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-lock"></span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-8">
                            <div class="card card-info">
                                <div class="card-header">
                                    <h6 class="card-title">Login credentials as superadmin</h6>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12 mb-2">
                                            <b>email :</b> </br> iamctbot@gmail.com
                                        </div>
                                        <div class="col-md-12">
                                            <b>pass :</b> </br>iamctbot
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-4">
                            <input type="hidden" class="btn btn-primary btn-block" value="Log In" name="submit_username">
                            <input type="submit" class="btn btn-primary btn-block btn-flat" value="Log In" name="login">
                        </div>
                        <!-- /.col -->
                    </div>
                </form>
                <?php
                echo $email_empty;
                echo $password_empty;
                echo $invalid_password;
                echo $invalid_email;
                ?>

                <!-- <div class="social-auth-links text-center mb-3">
                    <p>- OR -</p> -->
                <a href="signup.php" class="text-center btn btn-block btn-warning">Create new account
                </a>
                <!-- 
                    <a href="#" class="btn btn-block btn-danger">
                        <i class="fab fa-google-plus mr-2"></i> Sign in using Google+
                    </a> -->
                <!--  </div> -->
                <!-- /.social-auth-links -->

                <!-- <p class="mb-1">
                    <a href="forgot-password.html">I forgot my password</a>
                </p> -->
            </div>
            <!-- /.login-card-body -->
        </div>
    </div>
    <!-- /.login-box -->

    <!-- jQuery -->
    <script src="plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/adminlte.min.js"></script>

    <?php
    ob_end_flush();
    ?>
</body>

</html>